import java.util.*;

public class CalmActivity {
    private Stack<String> activityHistory;

    public CalmActivity() {
        activityHistory = new Stack<>();
    }

    public String performActivity(String mood) {
        String activity = "";
        switch (mood.toLowerCase()) {
            case "anxious":
                activity = "Try deep breathing for 5 minutes.";
                break;
            case "sad":
                activity = "Write down 3 things you’re grateful for.";
                break;
            case "angry":
                activity = "Go for a walk or do some stretches.";
                break;
            case "happy":
                activity = "Celebrate with your favorite song!";
                break;
            default:
                activity = "Drink water and take a short break.";
        }
        activityHistory.push(activity);
        return activity;
    }

    public String undoLastActivity() {
        if (!activityHistory.isEmpty()) {
            return "Undid activity: " + activityHistory.pop();
        } else {
            return "No activity to undo.";
        }
    }

    public List<String> getActivityHistory() {
        return new ArrayList<>(activityHistory);
    }
}
