import java.io.*;
import java.util.*;

public class Assistant {

    public static String predictMoodFromDiary(String diaryText) {
        String predictedMood = "";
        try {
            ProcessBuilder pb = new ProcessBuilder("python3", "predict_mood.py", diaryText);
            pb.redirectErrorStream(true);
            Process process = pb.start();

            BufferedReader reader = new BufferedReader(
                    new InputStreamReader(process.getInputStream()));

            predictedMood = reader.readLine();
            process.waitFor();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return predictedMood;
    }

    public static String generateQuoteForMood(String mood, QuoteProvider quoteProvider) {
        List<String> quotes = quoteProvider.searchByPrefix(mood.substring(0, Math.min(3, mood.length())));
        if (!quotes.isEmpty()) return quotes.get(0);
        return quoteProvider.getRandomQuote();
    }
}
