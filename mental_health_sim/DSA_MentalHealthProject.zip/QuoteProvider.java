import java.util.*;

class TrieNode {
    Map<Character, TrieNode> children = new HashMap<>();
    boolean isEndOfQuote = false;
    String quote = "";
}

public class QuoteProvider {
    private TrieNode root;

    public QuoteProvider() {
        root = new TrieNode();
    }

    public void addQuote(String quote) {
        TrieNode node = root;
        for (char c : quote.toCharArray()) {
            node = node.children.computeIfAbsent(c, k -> new TrieNode());
        }
        node.isEndOfQuote = true;
        node.quote = quote;
    }

    public List<String> searchByPrefix(String prefix) {
        List<String> results = new ArrayList<>();
        TrieNode node = root;
        for (char c : prefix.toCharArray()) {
            node = node.children.get(c);
            if (node == null) return results;
        }
        dfs(node, results);
        return results;
    }

    private void dfs(TrieNode node, List<String> results) {
        if (node.isEndOfQuote) results.add(node.quote);
        for (TrieNode child : node.children.values()) {
            dfs(child, results);
        }
    }

    public String getRandomQuote() {
        List<String> allQuotes = new ArrayList<>();
        dfs(root, allQuotes);
        if (allQuotes.isEmpty()) return "Stay positive!";
        Random rand = new Random();
        return allQuotes.get(rand.nextInt(allQuotes.size()));
    }
}
