public class Executer {
    public static void main(String[] args) {
        new MentalHealthUI();
    }
}
