public class User {
    private String name;
    private int age;
    private String moodPreference;

    public User(String name, int age, String moodPreference) {
        this.name = name;
        this.age = age;
        this.moodPreference = moodPreference;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public String getMoodPreference() {
        return moodPreference;
    }

    public void setMoodPreference(String moodPreference) {
        this.moodPreference = moodPreference;
    }
}
