import javax.swing.*;
import java.awt.event.*;
import java.time.LocalDate;

public class MentalHealthUI {
    private MoodTracker tracker;
    private QuoteProvider quoteProvider;
    private CalmActivity calmActivity;

    public MentalHealthUI() {
        tracker = new MoodTracker();
        quoteProvider = new QuoteProvider();
        calmActivity = new CalmActivity();

        quoteProvider.addQuote("Stay positive even when it feels impossible.");
        quoteProvider.addQuote("Take a deep breath and begin again.");

        createUI();
    }

    private void createUI() {
        JFrame frame = new JFrame("Mental Wellness AI");
        JTextField inputField = new JTextField(30);
        JTextArea output = new JTextArea(10, 40);
        JButton predictBtn = new JButton("Predict Mood & Help");

        predictBtn.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String diary = inputField.getText();
                String mood = Assistant.predictMoodFromDiary(diary);
                tracker.addMood(LocalDate.now(), mood);
                String quote = Assistant.generateQuoteForMood(mood, quoteProvider);
                String activity = calmActivity.performActivity(mood);

                output.setText("Predicted Mood: " + mood + "\n\nQuote: " + quote +
                        "\n\nRecommended Activity: " + activity);
            }
        });

        JPanel panel = new JPanel();
        panel.add(inputField);
        panel.add(predictBtn);
        panel.add(new JScrollPane(output));

        frame.add(panel);
        frame.pack();
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);
    }
}
