import java.time.LocalDate;
import java.util.*;

public class MoodTracker {
    private TreeMap<LocalDate, List<String>> moodLogs;
    private HashMap<String, Integer> moodFrequency;

    public MoodTracker() {
        moodLogs = new TreeMap<>();
        moodFrequency = new HashMap<>();
    }

    public void addMood(LocalDate date, String mood) {
        moodLogs.putIfAbsent(date, new ArrayList<>());
        moodLogs.get(date).add(mood);
        moodFrequency.put(mood, moodFrequency.getOrDefault(mood, 0) + 1);
    }

    public List<String> getMoodsOnDate(LocalDate date) {
        return moodLogs.getOrDefault(date, new ArrayList<>());
    }

    public List<String> getTopMoods(int topN) {
        PriorityQueue<Map.Entry<String, Integer>> pq =
                new PriorityQueue<>((a, b) -> b.getValue() - a.getValue());
        pq.addAll(moodFrequency.entrySet());

        List<String> result = new ArrayList<>();
        while (!pq.isEmpty() && result.size() < topN) {
            result.add(pq.poll().getKey());
        }
        return result;
    }

    public boolean hasMoodOn(LocalDate date) {
        return moodLogs.containsKey(date);
    }
}
